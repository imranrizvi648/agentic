"use client";
import { ReactLenis, useLenis } from "lenis/react";
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

export default function SmoothScroll({ children }) {
  const lenisRef = useRef();

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);

    // Sync GSAP ticker with Lenis
    function update(time) {
      lenisRef.current?.lenis?.raf(time * 1000);
    }

    gsap.ticker.add(update);

    return () => {
      gsap.ticker.remove(update);
    };
  }, []);

  return (
    <ReactLenis 
      root 
      ref={lenisRef}
      autoRaf={false} // Disable internal RAF to use GSAP's ticker
      options={{ 
        lerp: 0.1,         
        duration: 1.2, // Slightly lower duration feels more responsive
        smoothWheel: true,
        wheelMultiplier: 1, // Ensure this isn't too high
        touchMultiplier: 2,
      }}
    >
      {children}
    </ReactLenis>
  );
}